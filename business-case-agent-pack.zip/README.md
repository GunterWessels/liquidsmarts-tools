# Business Case Agent Pack

**LiquidSMARTS™ | Commercial Engineering Tools**

A portable AI agent team that transforms prospect context into a monetized business case — in a single copy-paste into any LLM.

---

## The Problem This Solves

Clinical champions love your product. They cannot win the internal budget battle because they cannot answer the CFO's first question: "What is this costing us today?"

This pack gives any rep or consultant a structured, six-agent workflow that:

1. Profiles the prospect's cost-of-failure (COF) deficits
2. Monetizes each deficit with explicit math
3. Maps your solution's gains to each deficit
4. Writes the executive narrative
5. Builds the financial gain matrix
6. Stress-tests every assumption from the CFO's chair

---

## How to Use in 5 Steps

1. **Open `00_your_context.md`** — fill in Layer A once (stable company/product info), then Layer B for each deal (5 fields per deal)
2. **Open `01_master_agent.md`** — copy the entire file
3. **Paste into your LLM of choice** — works with ChatGPT, Claude, Gemini, Grok, or Copilot
4. **Insert your filled context** where indicated in the prompt
5. **Hit send** — review Agent 6's CFO questions before presenting or distributing the output

---

## Extension Prompts

Each extension builds on the prior output. Paste the prior output at the top of each extension, then paste into a new chat session.

| File | Purpose |
|------|---------|
| `extensions/02_deep_research.md` | Industry trends + competitor analysis + analogous case studies |
| `extensions/03_stakeholder_map.md` | Per-stakeholder objection handling + champion internal pitch |
| `extensions/04_cfo_challenge.md` | Adversarial financial review — stress-tests every assumption |
| `extensions/05_champion_toolkit.md` | Leave-behind, hallway talking points, budget objection response |

---

## File Map

```
Business_Case_Agent_Pack/
├── README.md                    ← You are here
├── 00_your_context.md           ← Fill in once (stable) + per deal (5 fields)
├── 01_master_agent.md           ← The main event — paste into any LLM
├── extensions/
│   ├── 02_deep_research.md      ← Competitive + market depth
│   ├── 03_stakeholder_map.md    ← Per-person objection + talking points
│   ├── 04_cfo_challenge.md      ← CFO stress-tests every assumption
│   └── 05_champion_toolkit.md   ← Internal selling kit for your champion
└── reference/
    └── gain_matrix_blank.md     ← Blank template for manual sessions
```

---

## LiquidSMARTS™ Note

The base version uses generic value language (Operational / Financial / Strategic). The LiquidSMARTS™-parameterized version uses COF + ABC + Pipeline Velocity — which is the consulting upsell conversation.

To upgrade this pack to the full COF methodology, contact gunter@liquidsmarts.com.
