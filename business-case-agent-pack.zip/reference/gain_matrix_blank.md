# Gain Matrix — Blank Template

*For manual sessions, workshops, and whiteboard exercises. No LLM required.*

**LiquidSMARTS™ Commercial Engineering**

---

## How to Use This Template

This template is the financial backbone of any business case. Complete it with a prospect, a champion, or your internal team. It forces specificity on both sides of the value equation: what the problem is costing today, and what the solution is worth.

**Three rules:**
1. Every row must have a dollar figure — even if it is labeled Illustrative.
2. Show your math. Undocumented numbers get challenged.
3. Confidence labels are honest — do not upgrade an Illustrative to Estimated just because it looks better.

---

## Gain Matrix

| COF Dimension | Deficit | Gain Type | Current Annual Cost | Solution Gain | Annual Value | Confidence |
|---|---|---|---|---|---|---|
| Clinical | | | $ | | $ | |
| Operational | | | $ | | $ | |
| Financial | | | $ | | $ | |
| Clinical | | | $ | | $ | |
| Operational | | | $ | | $ | |

*Add or remove rows as needed. Minimum 3 rows for a defensible business case.*

---

## Column Definitions

| Column | What Goes Here |
|--------|---------------|
| **COF Dimension** | Clinical, Operational, or Financial |
| **Deficit** | Brief description of the problem — what is it costing them and why |
| **Gain Type** | What category of gain the solution delivers (Operational / Financial / Clinical) |
| **Current Annual Cost** | What this deficit costs the prospect per year at current volume |
| **Solution Gain** | Percentage improvement or unit reduction the solution delivers |
| **Annual Value** | Current Annual Cost × Solution Gain % |
| **Confidence** | High (proof point cited) / Estimated (benchmark + volume) / Illustrative (directional only) |

---

## Investment Summary

Complete after the matrix is filled in.

```
TOTAL ANNUAL VALUE:       $
ESTIMATED INVESTMENT:     $
PAYBACK PERIOD:           [Total Annual Value ÷ Monthly Cost =] months
3-YEAR VALUE:             $[Total Annual Value × 3]

Notes:
```

---

## Calculation Workspace

Use this section to document the math behind each row. One block per deficit.

**Deficit 1:**
```
Volume basis:
Calculation steps:
Annual cost =
Gain % basis (source):
Annual value =
```

**Deficit 2:**
```
Volume basis:
Calculation steps:
Annual cost =
Gain % basis (source):
Annual value =
```

**Deficit 3:**
```
Volume basis:
Calculation steps:
Annual cost =
Gain % basis (source):
Annual value =
```

**Deficit 4:**
```
Volume basis:
Calculation steps:
Annual cost =
Gain % basis (source):
Annual value =
```

**Deficit 5:**
```
Volume basis:
Calculation steps:
Annual cost =
Gain % basis (source):
Annual value =
```

---

## Confidence Level Guide

| Label | Meaning | When to Use |
|-------|---------|-------------|
| **High** | Dollar figure is directly supported by a cited proof point from a reference customer | You have a published or verifiable customer outcome that matches this calculation |
| **Estimated** | Dollar figure is calculated from the prospect's own volume data + industry benchmarks | You have the prospect's volume but are using benchmark improvement rates |
| **Illustrative** | Dollar figure is directional — based on typical ranges, not this prospect's data | You are missing volume data or improvement benchmarks; present for discussion only |

**Rule:** Any Illustrative row must be validated before the business case goes to committee.

---

## Completed Example (Reference)

| COF Dimension | Deficit | Gain Type | Current Annual Cost | Solution Gain | Annual Value | Confidence |
|---|---|---|---|---|---|---|
| Operational | Scope turnaround delays: 3 scopes × 12 repairs/year × $3,200 avg repair = $115,200 in repair costs + 45 min avg downtime per case | Financial | $115,200 | 100% elimination (single-use) | $115,200 | High — Memorial Hospital reference |
| Operational | Lost OR capacity: 4 cases/day delayed avg 45 min = 1 OR slot/day × 250 days × $2,800/OR hour = $175,000 in unrealized capacity | Financial | $175,000 | 80% recovery (ASSUMED: 4 of 5 delays eliminated) | $140,000 | Estimated |
| Financial | Staff overtime: 18% OT reduction cited in reference × 12 OR staff × $28/hr × 200 OT hours/year = $120,960 | Financial | $120,960 | 18% (St. Luke's reference) | $21,773 | High — St. Luke's reference |

```
TOTAL ANNUAL VALUE:     $276,973
ESTIMATED INVESTMENT:   $TBD — rep to confirm deal size
PAYBACK PERIOD:         TBD
3-YEAR VALUE:           $830,919
```

---

*Blank template. For the AI-assisted version that completes this automatically, use 01_master_agent.md.*
