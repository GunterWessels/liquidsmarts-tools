# Your Context — Business Case Agent Pack

Fill in this file before running `01_master_agent.md`. Paste the completed version where indicated in the master prompt.

---

## LAYER A — Stable Context (Fill Once)

*This section describes your company and solution. Update only when your offerings change.*

### Your Company

**Company name:**
[e.g., Acme Medical Devices]

**One-sentence description:**
[What your company does and for whom. e.g., "We provide minimally invasive surgical platforms for urological procedures in acute-care hospitals."]

---

### Your Solution

**Product or service name:**
[e.g., UroPath System]

**One-sentence description:**
[What it does and the primary gain it delivers. e.g., "UroPath reduces ureteroscopy procedure time by 30-40% through single-use disposable optics that eliminate sterilization delays."]

---

### Ideal Customer Profile

**Organization type and size:**
[e.g., 200+ bed acute-care hospitals with active urology service lines]

**Primary economic buyer:**
[e.g., VP/Director of Supply Chain, CFO, Service Line Director]

**Primary clinical champion:**
[e.g., Chief of Urology, Urologist, OR Director]

---

### Proof Points (Quantified — Reference Customers)

List your 3 strongest validated outcomes. Be specific. These anchor every dollar figure the agents produce.

1. [e.g., "St. Luke's Medical Center reduced ureteroscopy turnaround time from 45 min to 12 min, enabling 4 additional cases per OR day."]
2. [e.g., "Memorial Hospital eliminated $180,000/year in scope repair costs after switching to single-use."]
3. [e.g., "Regional Medical reduced OR staff overtime by 18% in the urology service line within 6 months of deployment."]

---

### Known Solution Gains (Optional — Strengthens Agent 3)

If you know where your solution creates measurable gains, list them here. Organized by dimension:

**Clinical gains:**
[e.g., "Reduces procedure time 15-20%"; "Eliminates scope reprocessing delays (45-90 min per case)"; "Reduces infection risk from sterilization failures"]

**Operational gains:**
[e.g., "Reduces OR staff training from 4 hours to 45 minutes"; "Eliminates scope inventory tracking burden"; "Enables same-day scheduling for add-on cases"]

**Financial gains:**
[e.g., "Eliminates $3,000-$12,000/year per scope in repair costs"; "Generates $X in incremental case revenue per recovered OR slot"; "Reduces supply carrying cost by eliminating loaner scope management"]

---

## LAYER B — Per Deal (Fill for Each Opportunity)

*5 fields. Fill fresh for each prospect. Replace prior entries — do not stack.*

### 1. Prospect Profile

**Company name:**
[e.g., Riverside Health System]

**Industry and segment:**
[e.g., Acute-care hospital system, Southeast US, not-for-profit]

**Approximate size:**
[e.g., 3 hospitals, 850 total beds, $420M annual revenue]

---

### 2. Solution Proposed

**What are you proposing for this deal?**
[Specific configuration, contract type, volume, or scope. e.g., "Full conversion of Riverside's 2 active OR suites to UroPath single-use platform. Estimated 120 ureteroscopy cases/year across both facilities."]

---

### 3. Key Stakeholders

List each stakeholder and their role in the buying process.

| Name | Title | Role |
|------|-------|------|
| [Name] | [Title] | Economic Buyer / Champion / Evaluator / Blocker |
| [Name] | [Title] | Economic Buyer / Champion / Evaluator / Blocker |
| [Name] | [Title] | Economic Buyer / Champion / Evaluator / Blocker |

---

### 4. Volume and Scale

*This field sizes the opportunity. The agents use it to calculate annual cost of inaction.*

[Provide any combination of: number of procedures/cases per year, number of users, number of locations, current spend on the category, or relevant throughput metric. e.g., "120 ureteroscopy cases/year. 3 scopes in current rotation. Scope repair contract = $28,000/year. 2 OR suites."]

---

### 5. Trigger Event (Optional — Strengthens Agent 1)

*What opened the door to this conversation?*

[e.g., "Scope sent for third repair in 12 months — CFO flagged the repair line item in Q3 review."]
[e.g., "New Chief of Urology joining in 60 days — wants to modernize service line before arrival."]
[e.g., "Joint Commission audit flagged sterilization documentation gaps."]
[Leave blank if unknown.]

---

*End of context file. Paste the completed version into `01_master_agent.md` where indicated.*
