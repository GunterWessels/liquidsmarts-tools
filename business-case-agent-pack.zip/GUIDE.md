# Business Case Agent Pack — User Guide

**LiquidSMARTS™ | Commercial Engineering Tools**

---

## What This Is

The Business Case Agent Pack is a set of prompts you paste into any AI tool — ChatGPT, Claude, Gemini, Grok, or Copilot — to produce a complete, monetized business case for any deal you are working.

You provide the context. The AI does the analysis, the math, and the writing.

The output you get is not a generic template. It is a specific business case for your specific prospect, with dollar figures tied to their volume and their situation.

---

## The Problem It Solves

You know your product creates value. Your clinical champion knows it too. But when the deal goes to committee, the CFO asks one question:

**"What is this costing us today if we do nothing?"**

Most reps cannot answer that question with a dollar figure. They talk about features, workflows, and clinical benefits. The committee hears: "nice to have." The deal stalls.

This pack gives you — and your champion — the financial argument. It calculates what the prospect is losing right now, maps your solution's gains to those losses, and produces both a narrative the economic buyer can read and a financial table they can defend.

---

## What You Get

Running the main prompt (`01_master_agent.md`) produces six sequential outputs:

| Agent | What It Produces |
|-------|-----------------|
| **Agent 1 — Situation Analyst** | 3-5 specific problems the prospect has today, each stated as a measurable gap |
| **Agent 2 — Deficit Monetizer** | The annual dollar cost of each problem, with math shown step by step |
| **Agent 3 — Solution Mapper** | What your solution fixes, how much of each loss it recovers, and what proof supports that claim |
| **Agent 4 — Case Writer** | A 400-word narrative business case written for the economic buyer — ready to send or present |
| **Agent 5 — Model Builder** | The gain matrix table: every deficit, every gain, every dollar, one payback period |
| **Agent 6 — CFO Reviewer** | The two or three weakest assumptions in your model — identified before the committee does |

The full output typically runs 1,200-1,800 words and is ready to use as the analytical foundation for a proposal, a leave-behind, or an internal champion presentation.

---

## The Four Extension Prompts

Once you have the main output, four optional extensions let you go deeper:

| Extension | What It Produces |
|-----------|-----------------|
| **02 — Deep Research** | Industry trends amplifying your prospect's problems + competitive weaknesses + analogous ROI cases |
| **03 — Stakeholder Map** | For each person in the buying group: their concern, their committee question, and the proof point that answers it. Plus the champion's 90-second internal pitch. |
| **04 — CFO Challenge** | An adversarial financial review. Challenges every dollar figure, stress-tests the model at 50% gains, and tells you exactly what to fix before committee. |
| **05 — Champion Toolkit** | A one-page executive summary, five hallway talking points, three questions to ask before the meeting, and a script for the budget objection. |

You do not need all four. Use the ones that fit the situation.

---

## What You Need Before You Start

Two things:

**1. Your stable information (fill once)**
- Your company name and what you do in one sentence
- Your product or service name and what it delivers
- Your ideal customer description
- Two or three proof points — specific, quantified outcomes from real customers

**2. Your deal information (fill per deal)**
- Prospect company name, industry, approximate size
- What you are proposing for this specific deal
- The key people in the buying process (name, title, role)
- Volume or scale data — how many procedures, users, locations, or dollars involved
- What opened the door to this conversation (optional, but useful)

All of this goes into `00_your_context.md`. It takes about 15 minutes to fill in for the first time. Each subsequent deal takes 5 minutes to update.

---

## Step-by-Step Instructions

### Step 1 — Fill in Your Context

Open `00_your_context.md`.

Fill in **Layer A** (your stable company and product information). You only do this once. Update it only when your offerings change.

Fill in **Layer B** (your deal-specific information). Five fields. Do this for each new prospect.

Save the file.

---

### Step 2 — Open the Master Prompt

Open `01_master_agent.md`.

Select all the text. Copy it.

---

### Step 3 — Open Your AI Tool

Go to ChatGPT, Claude, Gemini, Grok, Copilot, or any other AI assistant you use.

Start a new conversation.

Paste the master prompt text into the message field. Do not send yet.

---

### Step 4 — Add Your Context

In the master prompt, you will see this block:

```
--- BEGIN CONTEXT ---

[Paste your completed 00_your_context.md here — Layer A + Layer B both filled in]

--- END CONTEXT ---
```

Replace the placeholder text (the line in brackets) with everything from your filled-in `00_your_context.md` — Layer A and Layer B together.

Now send the message.

---

### Step 5 — Review the Output

The AI will work through all six agents in sequence. This typically takes 30-60 seconds depending on the tool.

When it finishes, read Agent 6 first. It will identify the weakest assumptions in the model. Address those before you present the business case to anyone.

Then read Agent 4 (the narrative) and Agent 5 (the gain matrix). These are your primary deliverables.

---

### Using the Extension Prompts (Optional)

Each extension prompt is self-contained. To use one:

1. Open the extension file (e.g., `extensions/03_stakeholder_map.md`)
2. Start a **new** conversation in your AI tool
3. Copy the full output from the master prompt (all six agents)
4. Paste that output at the top of the extension file, where it says `[Paste the complete output from 01_master_agent.md here]`
5. Copy the combined text and paste it into the new conversation
6. Send

Extensions work best in a fresh conversation — they are designed to receive the full prior output as context.

---

## How to Read the Gain Matrix

Agent 5 produces a table. Here is what each column means:

| Column | What It Means |
|--------|--------------|
| **COF Dimension** | Clinical, Operational, or Financial — the category of the problem |
| **Deficit** | The specific problem this row addresses |
| **Gain Type** | What category of improvement the solution delivers |
| **Current Annual Cost** | What this problem is costing the prospect per year today |
| **Solution Gain** | The percentage improvement your solution delivers |
| **Annual Value** | Current Annual Cost × Solution Gain — what you recover |
| **Confidence** | High, Estimated, or Illustrative — how well-supported this number is |

**Confidence levels explained:**

- **High** — The number is supported by a real customer proof point you provided. Defend it by name.
- **Estimated** — The number is calculated from the prospect's volume data plus industry benchmarks. Reasonable, but confirm with your reference team before presenting.
- **Illustrative** — The number is directional only. You are missing either volume data or a benchmark. Do not present this as a real number — use it to start a conversation and get the actual data.

**Rule:** Fix every Illustrative row before the business case goes to a committee meeting.

---

## Tips for Better Output

**Give specific numbers.** The more volume and scale data you provide in Layer B, the more precise the dollar figures will be. "120 ureteroscopy cases per year" produces better math than "active urology service line."

**Use real proof points.** Agent 3 maps your solution's gains to the prospect's deficits. It can only use proof points you provide. Generic claims produce generic outputs. Customer-specific numbers produce defensible outputs.

**Name the trigger event.** The trigger event (why the conversation opened) tells the AI what the prospect already knows is a problem. It sharpens Agent 1 significantly.

**Read Agent 6 before you present anything.** The CFO adversarial agent will find the weakest numbers before your prospect's CFO does. Use it.

**Run the CFO Challenge extension before large deals.** Extension 04 is a stress-test. If the model holds up at 50% gains, the case is strong. If it collapses, you need better data before you present.

---

## What the AI Cannot Do

This tool produces analysis based on the information you provide and the AI's training knowledge. It cannot:

- Access your prospect's internal financial data
- Verify numbers against live databases
- Replace the judgment call of a senior rep or consultant who knows the account
- Guarantee specific outcomes — every gain percentage is based on reference customers or benchmarks, not a prediction

The output is a structured starting point. You validate it against your account knowledge, then present it as your analysis — not the AI's.

---

## Frequently Asked Questions

**Can I use this with a free AI account?**
Yes. The prompts work with the free versions of ChatGPT (GPT-4o), Claude, and Gemini. Paid versions typically produce more precise outputs, but the structure holds across all tiers.

**Can I save and reuse outputs?**
Yes. Copy the AI's output and paste it into a document. We recommend keeping outputs in your CRM or a deal folder so you can track how the model evolved as you gathered more data.

**What if the AI skips an agent or combines steps?**
Paste the output back into the chat and write: "Please complete Agent [N] as specified, including the full output format." The prompts are written to prevent this, but some AI tools compress longer outputs. Explicitly requesting the format forces compliance.

**Can I share the output with my prospect?**
The narrative from Agent 4 and the summary from Agent 5 are written for sharing. Always review them first. Every Illustrative number should either be validated or removed before you share externally.

**How do I handle a prospect who wants to see the math?**
Show them the gain matrix (Agent 5) and the calculation logic from Agent 2. The prompts are designed to show work at every step. If they challenge a number, you have the calculation basis documented.

---

## Files in This Pack

```
Business_Case_Agent_Pack/
├── GUIDE.md                     ← You are here
├── README.md                    ← Quick reference (5 steps + file map)
├── 00_your_context.md           ← Fill in Layer A (once) + Layer B (per deal)
├── 01_master_agent.md           ← Main prompt — paste into any LLM
├── extensions/
│   ├── 02_deep_research.md      ← Industry + competitive + analogous cases
│   ├── 03_stakeholder_map.md    ← Per-person profiles + champion pitch
│   ├── 04_cfo_challenge.md      ← Adversarial financial stress-test
│   └── 05_champion_toolkit.md   ← Leave-behind + talking points + budget response
└── reference/
    └── gain_matrix_blank.md     ← Blank table for manual or workshop use
```

---

*Questions? Contact gunter@liquidsmarts.com*
