# Extension 03 — Stakeholder Map

*Paste the full output from `01_master_agent.md` at the top of this prompt, then paste the combined text into a new LLM chat session.*

---

## PRIOR BUSINESS CASE OUTPUT

[Paste the complete output from 01_master_agent.md here — all six agents]

---

## STAKEHOLDER MAP AGENT

Using the business case above, act as a relationship strategist. Your job is to arm the rep with the language and insight to navigate every stakeholder — including the ones who will try to kill the deal.

**Complete all three sections in sequence.**

---

### SECTION 1 — STAKEHOLDER PROFILES

For each stakeholder listed in the context, produce a profile.

**Output format:** For each stakeholder (use names and titles from the context):

> **[Name] — [Title] — [Role: Economic Buyer / Champion / Evaluator / Blocker]**
>
> **Primary concern:** [Which COF dimension (Clinical / Operational / Financial) drives their worldview and why]
>
> **The question they will ask in committee:** [Write the specific question this person is most likely to raise — not a category, but the actual words]
>
> **The proof point that addresses it:** [Which proof point from the business case answers their question most directly — cite it specifically]
>
> **What they need to feel confident:** [The one thing that must be true for them to say yes]

---

### SECTION 2 — THE BLOCKER

Identify the most likely blocker in this deal (from the stakeholder list or inferred from context). Produce a detailed counter-strategy.

**Output format:**

> **Most likely blocker:** [Name or role]
>
> **Their specific objection:** [Write the objection as they would actually state it — not a category]
>
> **Why they are raising it:** [The real concern behind the stated objection]
>
> **The response:** [How the champion or rep should address this — specific language, not general advice]
>
> **What to do before committee:** [One concrete action that reduces blocker resistance before the meeting]

---

### SECTION 3 — THE CHAMPION'S INTERNAL PITCH

Draft the champion's 90-second internal pitch. This is what they say when they are advocating for this deal without the rep in the room — in the hallway, at lunch, or in a side conversation with the economic buyer.

**Constraints:**
- No slides. No data tables. No jargon.
- Opens with the complication (what is it costing us today), not the solution.
- Closes with a clear ask (what do I need you to do, and by when).
- Uses the economic buyer's language, not the clinical champion's language.
- 90 seconds when read aloud at normal speaking pace (roughly 230 words).

**Output format:**

> **THE CHAMPION'S PITCH:**
> [Full text of the pitch, written in first person as the champion speaking]

---

*Stakeholder Map complete. The champion pitch can be included directly in the Champion Toolkit (Extension 05).*
