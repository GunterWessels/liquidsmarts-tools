# Extension 02 — Deep Research

*Paste the full output from `01_master_agent.md` at the top of this prompt, then paste the combined text into a new LLM chat session.*

---

## PRIOR BUSINESS CASE OUTPUT

[Paste the complete output from 01_master_agent.md here — all six agents]

---

## DEEP RESEARCH AGENT

Using the business case above as your foundation, act as a senior industry analyst. Your job is to add external market intelligence that strengthens the case and surfaces competitive threats.

**Complete all three sections in sequence.**

---

### SECTION 1 — INDUSTRY TRENDS

Identify 3 industry or regulatory trends that are amplifying the prospect's cost-of-failure deficits identified in the business case above.

**Output format:** For each trend:

> **Trend [N]:** [Name or label for the trend]
> **What is happening:** [2-3 sentences describing the trend with specifics — include time horizon and scale where possible]
> **How it amplifies the deficit:** [Which deficit from the business case does this make worse, and why]
> **Implication for the economic buyer:** [One sentence — what this means for the decision timeline]

---

### SECTION 2 — COMPETITIVE LANDSCAPE

Profile the top 2 competitors most likely to be in consideration for this deal.

**Output format:** For each competitor:

> **Competitor [N]:** [Company and product/service name]
> **Their positioning:** [How they frame their value — 2-3 sentences]
> **Their strongest claim:** [The one number or outcome they lead with]
> **Their positioning weakness:** [Where their argument is thin, outdated, or hard to defend under scrutiny]
> **Differentiation opportunity:** [One specific way the solution in this business case exploits that weakness]

If you do not have reliable competitor data, write: "Competitor intelligence not available — recommend rep pull vendor comparison data from internal sources before presenting."

---

### SECTION 3 — ANALOGOUS CASE STUDIES

Surface 2-3 analogous cases that strengthen the ROI claim in this business case. These may be public case studies, published outcomes, or illustrative scenarios drawn from industry benchmarks.

**Output format:** For each case:

> **Case [N]:** [Organization type and context — anonymize if no public reference]
> **The situation:** [What problem they faced, matched to a deficit in this business case]
> **The outcome:** [Quantified result — include timeframe]
> **How it applies:** [Why this case strengthens the gain matrix for this prospect]
> **Source:** [Public reference if available, or "Illustrative — based on [benchmark/study/published data]"]

---

*Deep Research complete. This output can be referenced when building the stakeholder map (Extension 03) or CFO challenge (Extension 04).*
