# Extension 05 — Champion Toolkit

*Paste the full output from `01_master_agent.md` at the top of this prompt, then paste the combined text into a new LLM chat session.*

---

## PRIOR BUSINESS CASE OUTPUT

[Paste the complete output from 01_master_agent.md here — all six agents]

---

## CHAMPION TOOLKIT AGENT

Using the business case above, act as a sales coach. Your job is to build an internal selling kit for the champion — the person inside the prospect organization who believes in this solution and has to advocate for it without you in the room.

The champion is not the economic buyer. They are brilliant at their clinical or operational job. They are less comfortable making financial arguments. They need tools, language, and confidence. Give them exactly that.

**Complete all four sections in sequence.**

---

### SECTION 1 — ONE-PAGE EXECUTIVE SUMMARY

Write a one-page executive summary suitable as a leave-behind for the economic buyer.

**Required elements:**

- **Header:** [Prospect Company Name] — Business Case Summary
- **The Situation** (2-3 sentences): What the current state looks like and the cost of staying there
- **The Opportunity** (2-3 sentences): What changes with the solution and what it is worth annually
- **The Evidence** (3 bullet points): Reference proof points from the business case — specific and quantified
- **The Investment** (1-2 sentences): Deal size and payback period from the gain matrix
- **Recommended Next Step** (1 sentence): A clear, single action for the economic buyer

**Formatting rules:**
- Plain text. No tables. No bullet forests.
- Every number must trace back to the business case.
- Total length: fits on one page when printed at 11pt font.

---

### SECTION 2 — FIVE HALLWAY TALKING POINTS

Write 5 talking points the champion uses in informal conversations — no slides, no data, just language. These are for the hallway, the lunch table, and the 60-second elevator moment.

**Rules:**
- Each talking point is 1-3 sentences max.
- Opens with a problem or cost, not a product feature.
- Uses specific numbers from the business case where possible.
- Ends with an implicit or explicit question that keeps the conversation moving.

**Output format:**

> **Talking Point 1:** [Text]
>
> **Talking Point 2:** [Text]
>
> *(and so on)*

---

### SECTION 3 — THREE QUESTIONS BEFORE THE COMMITTEE MEETING

Write the three questions the champion should ask — and get answered — before the committee meeting. These are intelligence-gathering questions directed at allies inside the organization.

**Output format:** For each question:

> **Question [N]:** [The actual question to ask]
> **Who to ask:** [Role, not name — the champion knows their org]
> **Why it matters:** [What knowing the answer changes about the champion's approach in committee]

---

### SECTION 4 — THE BUDGET OBJECTION RESPONSE

Write a direct, confident response to: "We don't have budget for this right now."

**Constraints:**
- 60-90 seconds when spoken aloud (roughly 120-180 words).
- Does not argue with the objection. Accepts the constraint and reframes it.
- Pivots to the cost of inaction using a specific number from the business case.
- Closes with a question, not a statement.
- Sounds like a human conversation, not a sales script.

**Output format:**

> **BUDGET OBJECTION RESPONSE:**
> [Full text of the response, written as the champion would actually say it]

---

*Champion Toolkit complete. The one-page executive summary can be dropped directly into a PDF or shared digitally. The talking points and budget response should be reviewed aloud before the committee meeting.*
